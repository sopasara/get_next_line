0123456789
567
ABCD
EFG
abcd



buffer, buffer_size

file = [line...line]


CASE 1:    buffer_size > line
    - How to get 'fat' for next line?



CASE 2:    buffer_size < line


Special cases:
    - What if first_line < buffer_size but second_line > buffer_size?
        -> reset n?




